<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Application List</h1>
    </div>
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route('admission.index')); ?>" class="form-inline mb-3">
                <input type="search" placeholder="Search by Anything.." name="keyword" class="form-control">
                <input type="submit" value="Search" class="btn btn-primary ml-2">
            </form>
            <table class="table table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Full name</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>School name</th>
                    <th>Index Number</th>
                    <th>Created at</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($item->first_name ." ". $item->middle_name ." ". $item->last_name); ?></td>
                        <td><?php echo e($item->gender); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->school_name); ?></td>
                        <td><?php echo e($item->index_number); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td>
                            <div class="float-right">
                                <a href="<?php echo e(route('admission.show', $item)); ?>" class="btn btn-info btn-sm">Detail</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($admissions->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/admissions/index.blade.php ENDPATH**/ ?>