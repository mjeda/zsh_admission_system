<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Payment List</h1>
    </div>
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route('payments')); ?>" class="form-inline mb-3">
                <input type="search" placeholder="Search by Anything.." name="keyword" class="form-control">
                <input type="submit" value="Search" class="btn btn-primary ml-2">
            </form>
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Applicant Name</th>
                    <th>Control number</th>
                    <th>Amount</th>
                    <th>Received By</th>
                    <th>Date</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($payment->controlNumber->admission->first_name .' '. $payment->controlNumber->admission->middle_name .' '. $payment->controlNumber->admission->last_name); ?></td>
                        <td><?php echo e($payment->controlNumber->control_number); ?></td>
                        <td><?php echo e($payment->amount); ?></td>
                        <td><?php echo e($payment->user->name); ?></td>
                        <td><?php echo e($payment->payment_date); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($payments->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/payments/index.blade.php ENDPATH**/ ?>