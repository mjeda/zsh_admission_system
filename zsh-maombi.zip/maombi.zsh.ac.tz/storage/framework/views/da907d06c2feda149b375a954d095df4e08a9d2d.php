<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>