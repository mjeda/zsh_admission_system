<div>
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-title">
                <h5 class="text-muted font-weight-bold">Send mobile sms to the students</h5>
            </div>
            <div class="row">
                <div class="col">
                    <!--  form  -->
                    <div>
                        <div>
                            <label for="message">Message:</label>
                            <textarea wire:model="message" rows="4" cols="50" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                            <?php $__errorArgs = ["message"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="row">
                            <div class="col">
                                <label for="status">Intake:</label>
                                <select wire:model="intake" class="form-control mr-2 <?php $__errorArgs = ['intake'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select-2">
                                    <option value="">-- Select Intake --</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($intake->id); ?>" <?php if(request('intake') == $intake->id): ?> selected <?php endif; ?>><?php echo e($intake->title. " round - ". $intake->round .", ". $intake->year); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ["intake"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col">
                                <label for="status">Status:</label>
                                <select wire:model="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">-- Select status --</option>
                                    <option value="CREATED">Created</option>
                                    <option value="SUBMITTED">Submitted</option>
                                    <option value="SELECTED">Selected</option>
                                </select>
                                <?php $__errorArgs = ["status"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col">
                                <button wire:click="filterStudent" type="button" class="btn btn-primary">filter student</button>
                            </div>
                            <?php if(!empty($admissions)): ?>
                            <div class="col">
                                <button wire:click="sendSms" type="button" class="pull-right" class="btn btn-success">Send SMS</button>
                            </div>
                            <?php endif; ?>
                        </div>
                    <div>
                    <!-- student list  -->
                    <div class="mt-4">
                        <table class="table table-striped border-left border-right border-bottom">
                            <thead>
                            <tr>
                                <th width="35px" class="border-right">SN</th>
                                <th>Full name</th>
                                <th>Gender</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>School name</th>
                                <th>Index Number</th>
                                <th>Created at</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e($item->first_name ." ". $item->middle_name ." ". $item->last_name); ?></td>
                                    <td><?php echo e($item->gender); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    <td><?php echo e($item->school_name); ?></td>
                                    <td><?php echo e($item->index_number); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <div class="float-right">
                                            <button type="button" class="btn btn-danger btn-sm" wire:click="cancel(<?php echo e($loop->index); ?>)" 
                                                onclick="confirm('Are you sure you want to remove the student?') || event.stopImmediatePropagation()">
                                                Cancel
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center">
                                    No content in this table
                                </td>
                            </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/livewire/sms-component.blade.php ENDPATH**/ ?>