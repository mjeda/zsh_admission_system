<?php $__env->startPush('style'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Admission Selection</h1>
    </div>
    <div class="row">
        <div class="col">
            <div class="d-flex justify-content-start mb-2">
                <form class="form-inline">
                    <select name="intake" class="form-control mr-2 <?php $__errorArgs = ['intake'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> bg-dark text-light <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select-2">
                        <option value="">-- Select Intake --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($intake->id); ?>" <?php if(request('intake') == $intake->id): ?> selected <?php endif; ?>><?php echo e($intake->type. ' - '. $intake->title. " round ". $intake->round .", ". $intake->year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                    <select name="course" class="form-control mx-2 <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> bg-dark text-light <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">-- Select Course --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($course->id); ?>" <?php if(request('course') == $course->id): ?> selected <?php endif; ?>><?php echo e($course->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                    <select name="choice" class="form-control mr-2 <?php $__errorArgs = ['choice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> bg-dark text-light <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                       <option value="">-- Select Choice --</option>
                       <option value="1"> First Choice</option>
                       <option value="2"> Second Choice</option>
                       <option value="3"> Third Choice</option>
                   </select>

                    <input type="submit" value="Filter by Course" class="btn btn-success">

                </form>
                <?php if(request('course') && request('intake')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('collect selected')): ?>
                  <a href="#" id="collect" class="btn btn-primary ml-2"> Collect Selected</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view collection')): ?>
                  <a href="<?php echo e(route('selections.collection', [request('course'), request('intake')])); ?>"  class="btn btn-warning ml-2"> View  Collection</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>

            <div>
                <table class="table table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th width="35px" class="border-right">SN</th>
                        <th style="width: 15%">Full name</th>
                        
                        
                        
                        <th>Index Number</th>
                        
                        <th>Points</th>
                        <th style="width: 50%">Result</th>
                        <th>Apply Date</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('collect selected')): ?>
                        <th class="text-primary font-weight-bold"><a href="#" class="nav-item" id="selectAll">Select All</a></th>
                        <?php endif; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <form id="selectionForm" method="post" action="<?php echo e(route('selections.collect')); ?>">
                        <input type="hidden" name="course" value="<?php echo e(request('course')); ?>">
                        <input type="hidden" name="intake" value="<?php echo e(request('intake')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $selections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                                <td><a href="<?php echo e(route('admission.show', $item->admission->id)); ?>">
                                        <?php echo e($item->admission->first_name ." ". $item->admission->middle_name ." ". $item->admission->last_name); ?></a>
                                </td>
                                
                                
                                
                                <td><?php echo e($item->admission->index_number); ?></td>
                                
                                <td><?php echo e($item->admission->points); ?></td>
                                <td>
                                    <?php if(isset($item->admission->results[0]->result_payload)): ?>
                                        <?php
                                            $resultPayload = json_decode($item->admission->results[0]->result_payload);
                                            $displayedCount = 0;
                                        ?>
                                        <?php if(isset($resultPayload->subjects)): ?>
                                            <?php $__currentLoopData = $resultPayload->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(in_array($subject->grade, ['D', 'C', 'B', 'A']) and $displayedCount < 6): ?>
                                                    <?php if($subject->subject_name == 'BIOLOGY'): ?>
                                                        BIO
                                                    <?php elseif($subject->subject_name == 'CHEMISTRY'): ?>
                                                        CHEM 
                                                    <?php elseif($subject->subject_name == 'PHYSICS'): ?>
                                                        PHY 
                                                    <?php elseif($subject->subject_name == 'ENGLISH LANGUAGE'): ?>
                                                        ENG 
                                                    <?php elseif($subject->subject_name == 'GEOGRAPHY'): ?>
                                                        GEO 
                                                    <?php elseif($subject->subject_name == 'BASIC MATHEMATICS'): ?>
                                                        MATH 
                                                    <?php elseif($subject->subject_name != 'ELIMU YA DINI YA KIISLAMU'): ?>
                                                        <?php echo e($subject->subject_name); ?> 
                                                    <?php endif; ?>
                                                     : <strong><?php echo e($subject->grade); ?></strong>
                                                    <?php
                                                        $displayedCount++;
                                                    ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date_format($item->admission->created_at, "d-m-Y")); ?></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('collect selected')): ?>
                                <td>
                                    <div class="float-right">
                                        <input type="checkbox" name="selected[]" value="<?php echo e($item->admission->id); ?>"
                                            class="picker form-check-input" id="<?php echo e($item->admission->id); ?>">
                                        <label class="form-check-label text-success font-weight-bold"
                                            for="<?php echo e($item->admission->id); ?>">Select</label>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    </form>
                    <tr>
                        <td colspan="10" class="text-center">
                            No content in this table
                        </td>
                    </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        let state = false;
        $('#selectAll').on('click', function () {
            state = !state
            $('.picker').prop('checked', state)
        })

        $('#collect').on('click', function () {
            alert('we got it')
            $('#selectionForm').submit()
        })

        $(document).ready(function() {
            $('.select-2').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/selections/index.blade.php ENDPATH**/ ?>