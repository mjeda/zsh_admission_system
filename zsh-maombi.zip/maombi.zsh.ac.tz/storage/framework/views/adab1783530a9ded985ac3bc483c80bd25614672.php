<?php $__env->startSection('content'); ?>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">View Verified Student</h1>
    </div>
    <div class="row">
        <!-- filter form -->
        <div class="col">
            <div class="d-flex justify-content-start mb-2">
                <form class="form-inline">
                    <select name="intake" class="form-control mr-2 select-2">
                        <option value="">-- Select Intake --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($intake->id); ?>" <?php if(request('intake') == $intake->id): ?> selected <?php endif; ?>><?php echo e($intake->title. " round - ". $intake->round .", ". $intake->year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                    <select name="course" class="form-control mx-2">
                        <option value="">-- Select Course --</option>
                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($course->id); ?>" <?php if(request('course') == $course->id): ?> selected <?php endif; ?>><?php echo e($course->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>

                    <button type="submit" class="btn btn-primary float-end">
                        Filter
                    </button>

                    <?php if(count($submitted) > 0): ?>
                        <a href="<?php echo e(route('nacte.enrol.all.student', [request()->query('course'), request()->query('intake')])); ?>" class="btn btn-info float-end mx-2">
                            enroll all
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Username</th>
                    <th>Multi Selection</th>
                    <th>Academic Year</th>
                    <th>Intake</th>
                    <th>Eligibility</th>
                    <th>Remark</th>
                    <th>Verification Status</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $submitted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($item->username); ?>}</td>
                        <td><?php echo e($item->multiple_selection); ?></td>
                        <td><?php echo e($item->academic_year); ?></td>
                        <td><?php echo e($item->intake); ?></td>
                        <td><?php echo e($item->eligibility); ?></td>
                        <td><?php echo e($item->remarks); ?></td>
                        <td><?php echo e($item->verification_status); ?></td>
                        <td>
                            <a href="<?php echo e(route('nacte.enrol.student', [$item->user_id, request()->query('course'), $item->intake, $item->academic_year])); ?>" class="btn btn-primary" onclick="return confirm('Are you sure you want to enrol this student?')">
                                <i class="fa fa-refresh"></i> Enrol
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="text-center">
                            No content in this table
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/nacte/verified-students.blade.php ENDPATH**/ ?>