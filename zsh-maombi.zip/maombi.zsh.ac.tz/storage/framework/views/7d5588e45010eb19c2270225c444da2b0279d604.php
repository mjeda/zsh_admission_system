<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Payment Report</h1>
    </div>
    <div class="row">
        <div class="col">
            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('report.payment')); ?>" class="form-inline mb-3">
                        <div class="form-group">
                            <label class="mr-1">Method:</label>
                            <select name="method" class="form-control">
                                <option value="">--- Select ---</option>
                                <option value="cash">Cash</option>
                                <option value="bank">Bank</option>
                            </select>
                        </div>
                        <div class="form-group ml-3">
                            <label class="mr-1">Start Date:</label>
                            <input type="date" name="start_date" class="form-control">
                        </div>
                        <div class="form-group ml-3">
                            <label class="mr-1">End Date:</label>
                            <input type="date" name="end_date" class="form-control">
                        </div>

                        <div class="btn-group">
                            <input type="submit" value="Filter" class="btn btn-primary ml-2 pull">
                            <a href="<?php echo e(route('report.payment')); ?>" class="btn btn-light">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download payment report')): ?>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-secondary float-right" id="print_btn">
                            Print
                        </button>
                    </div>
                <?php endif; ?>
            </div>

            <div class="table-responsive" id="div_to_print">
                <?php echo $notify; ?>

                <table class="table  table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th width="35px" class="border-right">SN</th>
                        <th>Control number</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Received By</th>
                        <th>Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($payment->controlNumber->control_number); ?></td>
                            <td><?php echo e($payment->amount); ?></td>
                            <td><?php echo e($payment->payment_method); ?></td>
                            <td class="text-capitalize"><?php echo e($payment->user->name); ?></td>
                            <td><?php echo e($payment->payment_date); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center">
                                No content in this table
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td></td>
                            <td></td>
                            <td class="font-weight-bold">TZS <?php echo e($payments->sum('amount')); ?>/=</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('printThis/jquery.printThis.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(e) {
           $('button#print_btn').on('click', function(e)  {
                $('#div_to_print').printThis({
                    styles: ["<?php echo e(asset("css/bootstrap.css")); ?>"]
                    // exclude: ['.do_not_print', '.print_exclude' ]
                    // also accept array input: exclude: [<array>]
                    // you can specify id, class or even html element tag
                });
           });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/reports/payments.blade.php ENDPATH**/ ?>