<?php if($notification = Session::get('warning')): ?>
    <div class="alert alert-warning alert-block mt-2">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($notification); ?></strong>
    </div>
<?php endif; ?>

<?php if($notification = Session::get('success')): ?>
    <div class="alert alert-success alert-block mt-2">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($notification); ?></strong>
    </div>
<?php endif; ?>


<?php if($notification = Session::get('error')): ?>
    <div class="alert alert-danger alert-block mt-2">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($notification); ?></strong>
    </div>
<?php endif; ?>

<?php if($notification = Session::get('info')): ?>
    <div class="alert alert-info alert-block mt-2">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($notification); ?></strong>
    </div>
<?php endif; ?>
<?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/errors.blade.php ENDPATH**/ ?>