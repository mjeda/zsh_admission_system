<?php $__env->startSection('content'); ?>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">View Approval Status</h1>
    </div>
    <div class="row">
        <div class="col">
            <div class="d-flex justify-content-between mb-2">
                    <a href="<?php echo e(url()->previous()); ?>"  class="btn btn-success ml-2"> Back to Collection</a>

            </div>

            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Username</th>
                    <th>Multi Selection</th>
                    <th>Academic Year</th>
                    <th>Intake</th>
                    <th>Eligibility</th>
                    <th>Remark</th>
                    <th>Verification Status</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $submissions->params??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->username); ?>}</td>
                            <td><?php echo e($item->multiple_selection); ?></td>
                            <td><?php echo e($item->academic_year); ?></td>
                            <td><?php echo e($item->intake); ?></td>
                            <td><?php echo e($item->eligibility); ?></td>
                            <td><?php echo e($item->remarks); ?></td>
                            <td><?php echo e($item->verification_status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/selections/show_approval_index.blade.php ENDPATH**/ ?>