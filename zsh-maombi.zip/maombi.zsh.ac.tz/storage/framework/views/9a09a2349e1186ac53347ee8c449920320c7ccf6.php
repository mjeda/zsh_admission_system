<?php $__env->startSection('content'); ?>
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div>
                <h4 class="card-title mb-1">Account Setting</h4>
                <p class="text-muted mb-0">
                    Use this section to update your password and basic personal information. For any additional changes, please contact the system administrator.
                </p>
            </div>

            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('user.update.password')); ?>" method="POST" class="pb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col pt-3 pr-3 pl-3">
                                <label class="form-label">Current password</label>
                                <input wire:model="current_password" type="password" name="current_password" class="form-control  <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Current password">
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-6 pt-2 pr-3 pl-3">
                                <label for="password">Password</label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="Password">
                                <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6 pt-2 pr-3 pl-3">
                                <label for="conf_password">Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation" id="conf_password" placeholder="confirm Password">
                            </div>
                        </div>
                        <div class="row  pt-3 pr-4">
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary" name ="add_user">Change password</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/portal/change-password.blade.php ENDPATH**/ ?>