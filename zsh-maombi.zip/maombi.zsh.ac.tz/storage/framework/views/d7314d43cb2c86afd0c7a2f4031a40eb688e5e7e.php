<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <form method="GET" class="d-flex">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <select name="intake" class="form-select">
                    <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($intake->id); ?>" <?php if(request('intake') == $intake->id): ?> selected <?php endif; ?>><?php echo e($intake->type. ' - '. $intake->title. " round ". $intake->round .", ". $intake->year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-filter"> Filter</i>
                </button>
            </div>
        </form>
    </div>
    <div class="mt-n22 px-6">
        <!-- row for admission card -->
        <div class="row mt-2">
            <div class="col-12">
                <div class="row">
                    <div class="col-md-4 col-12 mt-6">
                        <!-- card -->
                        <div class="card rounded-3">
                            <!-- card body -->
                            <div class="card-body bg-light">
                                <!-- heading -->
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h4 class="mb-0">
                                            <form action="<?php echo e(route('admission.index')); ?>">
                                                <input hidden="" type="text" name="status" class="form-control" value="">
                                                <input hidden="" type="text" name="intake" class="form-control" value="<?php echo e($last_intake->id); ?>">
                                                <button type="submit" value="Search" class="btn btn-link text-gray-300 text-dark font-weight-bold" style="font-size: 18px; text-decoration: none">
                                                    Total Applications
                                                </button>
                                            </form>
                                        </h4>
                                    </div>
                                    <div class="icon-shape icon-md bg-light-primary text-primary rounded-1">
                                        <i class="fa fa-users fs-4"></i>
                                    </div>
                                </div>
                                <!-- project number -->
                                <div class="px-2">
                                    <h1 class="fw-bold"><?php echo e($total_admission); ?></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12 mt-6">
                        <!-- card -->
                        <div class="card rounded-3">
                            <!-- card body -->
                            <div class="card-body text-info bg-light">
                                <!-- heading -->
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h4 class="mb-0">
                                            <form action="<?php echo e(route('admission.index')); ?>">
                                                <input hidden="" type="text" name="status" class="form-control" value="CREATED">
                                                <input hidden="" type="text" name="intake" class="form-control" value="<?php echo e($last_intake->id); ?>">
                                                <button type="submit" value="Search" class="btn btn-link text-gray-300 text-info font-weight-bold" style="font-size: 18px; text-decoration: none">
                                                    In-progress Applications
                                                </button>
                                            </form>
                                        </h4>
                                    </div>
                                    <div class="icon-shape icon-md bg-light-primary text-primary rounded-1">
                                        <i class="fa fa-user fs-4"></i>
                                    </div>
                                </div>
                                <!-- project number -->
                                <div class="px-2">
                                    <h1 class="fw-bold"><?php echo e($created_admission); ?></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12 mt-6">
                        <!-- card -->
                        <div class="card rounded-3">
                            <!-- card body -->
                            <div class="card-body bg-light text-success">
                                <!-- heading -->
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h4 class="mb-0">
                                            <form action="<?php echo e(route('admission.index')); ?>">
                                                <input hidden="" type="text" name="status" class="form-control" value="SUBMITTED">
                                                <input hidden="" type="text" name="intake" class="form-control" value="<?php echo e($last_intake->id); ?>">
                                                <button type="submit" value="Search" class="btn btn-link text-gray-300 text-success font-weight-bold" style="font-size: 18px; text-decoration: none">
                                                    Completed Applications
                                                </button>
                                            </form>
                                        </h4>
                                    </div>
                                    <div class="icon-shape icon-md bg-light-primary text-primary rounded-1">
                                        <i class="fa fa-sticky-note fs-4"></i>
                                    </div>
                                </div>
                                <!-- project number -->
                                <div class="px-2">
                                    <h1 class="fw-bold"><?php echo e($submitted_admission); ?></h1>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- row Collection of admissions by course  -->
        <div class="row mt-2">
            <div class="col-12 col-md-8">
                <div class="card">
                    <div class="card-body">
                        <label class="label label-success">Collection of applications by course </label>
                        <div>
                            <canvas id="admission-chart" height="140"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Pie chart -->
            <div class="col-12 col-md-4">
                <div class="card">
                    <div class="card-body">
                        <label class="label label-success">Selected student by course</label>
                        <div>
                            <canvas id="myChart" height="140"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- row for table display admission for today  -->
        <div class="row mt-2">
            <div class="col-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <label class="label label-success">Today's <b>Applicant Admissions</b></label>
                        <div class="table-responsive">
                            <table class="table table-striped border-left border-right border-bottom">
                                <thead>
                                <tr>
                                    <th width="35px" class="border-right">SN</th>
                                    <th>Full name</th>
                                    <th>Gender</th>
                                    <th>Phone</th>
                                    <th>School name</th>
                                    <th>Index Number</th>
                                    <th>Created at</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $today_admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($item->first_name ." ". $item->middle_name ." ". $item->last_name); ?></td>
                                        <td><?php echo e($item->gender); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                        <td><?php echo e($item->school_name); ?></td>
                                        <td><?php echo e($item->index_number); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td>
                                            <div class="float-right">
                                                <a href="<?php echo e(route('admission.show', $item)); ?>" class="btn btn-info btn-sm">Detail</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">
                                            No content in this table
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <?php if($today_admissions): ?>
                            <?php echo e($today_admissions->links()); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const course = document.getElementById('admission-chart');

        new Chart(course, {
            type: 'bar',
            data: {
                labels: <?php echo e(Js::from($course_name)); ?>,
                datasets: [
                    {
                        label: '# of admissions',
                        data: <?php echo e(Js::from($course_value)); ?>,
                        borderWidth: 1
                    },
                    {
                        label: '# of first choice',
                        data: <?php echo e(Js::from($first_choice)); ?>,
                        borderWidth: 1
                    },
                    {
                        label: '# of seecond choice',
                        data: <?php echo e(Js::from($second_choice)); ?>,
                        borderWidth: 1
                    },
                    {
                        label: '# of third choice',
                        data: <?php echo e(Js::from($third_choice)); ?>,
                        borderWidth: 1
                    },
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const ctx = document.getElementById('myChart');

        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo e(Js::from($selected_course_name)); ?>,
                datasets: [{
                    label: ' # Selected students ',
                    data: <?php echo e(Js::from($selected_course_value)); ?>,
                    hoverOffset: 4,
                }]
            },
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/dashboard.blade.php ENDPATH**/ ?>