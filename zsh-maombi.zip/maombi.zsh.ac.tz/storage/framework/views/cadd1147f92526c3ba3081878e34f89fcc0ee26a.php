<?php echo e($slot); ?>

<?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>