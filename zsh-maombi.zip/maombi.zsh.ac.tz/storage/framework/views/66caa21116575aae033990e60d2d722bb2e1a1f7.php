<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage SMS</h1>
    </div>
    <!-- Form --->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['add intake', 'edit intake'])): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sms-component')->html();
} elseif ($_instance->childHasBeenRendered('FU0fJRV')) {
    $componentId = $_instance->getRenderedChildComponentId('FU0fJRV');
    $componentTag = $_instance->getRenderedChildComponentTagName('FU0fJRV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FU0fJRV');
} else {
    $response = \Livewire\Livewire::mount('sms-component');
    $html = $response->html();
    $_instance->logRenderedChild('FU0fJRV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/sms/index.blade.php ENDPATH**/ ?>