<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Courses</h1>
    </div>
    <!-- Form --->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['add course','edit course'])): ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-title">
                <h5 class="text-muted font-weight-bold"><?php if($course->exists): ?> Edit <?php else: ?> Add <?php endif; ?> Course</h5>
            </div>
            <div class="row">
                <div class="col">
                    <form action="<?php if($course->exists): ?> <?php echo e(route('course.update', $course)); ?> <?php else: ?> <?php echo e(route('course.store')); ?> <?php endif; ?>" method="POST" class="pb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12 col-md-6 pt-3 pr-3 pl-3">
                                <label for="code">Course Code</label>
                                <input type="text" value="<?php echo e($course->code); ?>" class="form-control  <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="code" id="code" placeholder="Code">
                                <?php $__errorArgs = ["code"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="tag">Course Tag</label>
                                <input type="text" value="<?php echo e($course->tag); ?>" class="form-control  <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tag" id="tag" placeholder="Tag">
                                <?php $__errorArgs = ["tag"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="type">Course Type</label>
                                <select id="type" name="type" class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="<?php echo e($course->type ?? ""); ?>"><?php echo e($course->type ?? "--- Select type ---"); ?></option>
                                    <?php if($course->exists): ?>
                                        <?php if($course->type == "Diploma"): ?>
                                            <option value="VTA/VETA">VTA/VETA</option>
                                        <?php else: ?>
                                            <option value="Diploma">Diploma</option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="Diploma">Diploma</option>
                                        <option value="VTA/VETA">VTA/VETA</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ["filtered"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="passes">Number of Passes</label>
                                <input type="number" value="<?php echo e($course->passes); ?>" class="form-control <?php $__errorArgs = ['passes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="passes" id="passes" placeholder="Passes">
                                <?php $__errorArgs = ["passes"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6 pt-3 pr-3 pl-3">
                                <label for="name">Course Name</label>
                                <input type="text" value="<?php echo e($course->name); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" placeholder="Name">
                                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-6 pt-3 pr-3 pl-3">
                                <label for="filtered">Subjects</label>
                                <select id="filtered" name="filtered" class="form-select <?php $__errorArgs = ['filtered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option><?php echo e($course->filtered); ?></option>
                                    <option>Any except excluded in criteria</option>
                                    <option>From Criteria except excluded</option>
                                </select>
                                <?php $__errorArgs = ["filtered"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row  pt-3 pr-4">
                            <div class="col">
                                <div class="btn-group">
                                    <button type="submit" class="btn btn-sm <?php if($course->exists): ?> btn-success <?php else: ?> btn-primary <?php endif; ?>" >
                                        <?php if($course->exists): ?> Edit <?php else: ?> Add <?php endif; ?> course
                                    </button>
                                    <?php if($course->exists): ?>
                                        <a href="<?php echo e(route("course.index")); ?>" class="btn btn-light btn-sm">Cancel</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- List --->
    <div class="row">
        <div class="col">
            <table class="table table-responsive table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th width="450">Course Name</th>
                    <th>Tag</th>
                    <th>Type</th>
                    <th class="text-nowrap">Subjects</th>
                    <th>Status</th>
                    <th>Passes</th>
                    <th>Created_at</th>
                    <th>Updated_at</th>
                    <th width="200"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td class="text-nowrap"><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->tag); ?></td>
                        <td class="text-nowrap"><?php echo e($item->type); ?></td>
                        <td class="text-nowrap"><?php echo e($item->filtered); ?></td>
                        <td>
                            <?php if($item->status == "Open"): ?>
                                <strong class="text-info ">Open</strong>
                            <?php else: ?>
                                <strong class="text-danger ">Close</strong>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->passes); ?></td>
                        <td><?php echo e(date_format($item->created_at, 'd-m-y')); ?></td>
                        <td><?php echo e(date_format($item->updated_at, 'd-m-y')); ?></td>
                        <td>
                            <div class="btn-group float-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('change course status')): ?>
                                    <a href="<?php echo e(route('course.status', $item)); ?>" class="btn <?php echo e(($item->status == "Open") ? "btn-danger" : "btn-info"); ?>  btn-sm"
                                       onclick="return confirm('Are you sure! \nDo you want to <?php echo e(($item->status == "Open") ? "Close" : "Open"); ?> ?')">
                                        <?php echo e(($item->status == "Open") ? "Close" : "Open"); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view criteria')): ?>
                                    <a href="<?php echo e(route('criteria.index', $item)); ?>" class="btn btn-warning btn-sm">Criteria</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit course')): ?>
                                <a href="<?php echo e(route('course.index', $item)); ?>" class="btn btn-success btn-sm">Edit</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete course')): ?>
                                <a href="<?php echo e(route('course.delete', $item)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ! \nDo you want to delete ?')">Remove</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($courses->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/courses/index.blade.php ENDPATH**/ ?>