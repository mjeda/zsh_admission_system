<?php $__env->startSection('content'); ?>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Collection View</h1>
    </div>
    <div class="row">
        <div class="col">
            <div class="d-flex justify-content-between mb-2">
                    <a href="<?php echo e(route('selections')); ?>"  class="btn btn-success ml-2"> Back to Selection</a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('submit to NACTE')): ?>
                <form class="form-inline" action="<?php echo e(route('selections.submission', ['course' => $course, 'intake' => $intake])); ?>">
                    <label for="receipt">Receipt Number:</label>
                    <input type="text" name="receipt" class="form-control ml-2" id="receipt" required>
                    <button type="submit" class="btn btn-primary ml-2">Submit to NACTE</button>
                </form>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view submission')): ?>
                <a href="<?php echo e(route('selections.submission_index', [$course, $intake])); ?>" class="btn btn-success ml-2">View Submission</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view status')): ?>
                <a href="<?php echo e(route('selections.submission_approval_index', [$course, $intake])); ?>" class="btn btn-success ml-2">View Status</a>
                <?php endif; ?>
            </div>

            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Full name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>School name</th>
                    <th>Index Number</th>
                    <th>Result</th>
                    
                    <th>Status</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('remove collection selected')): ?>
                    <th class="font-weight-bold">Action</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                            <td><a href="<?php echo e(route('admission.show', $item->admission->id)); ?>">
                                    <?php echo e($item->admission->first_name ." ". $item->admission->middle_name ." ". $item->admission->last_name); ?></a>
                            </td>
                            <td><?php echo e($item->admission->email); ?></td>
                            <td><?php echo e($item->admission->phone); ?></td>
                            <td><?php echo e($item->admission->school_name); ?></td>
                            <td><?php echo e($item->admission->index_number); ?></td>
                            <td><?php echo e($item->course->name); ?></td>
                            
                            <td><?php echo e($item->status); ?></td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('remove collection selected')): ?>
                            <td>
                                <?php if($item->status == 'SELECTED'): ?>
                                <div class="float-right">
                                  <a href="<?php echo e(route('selections.delete', $item->id)); ?>" class="nav-item text-danger" onclick="return confirm('Are you sure ?')">Remove</a>
                                </div>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/selections/show.blade.php ENDPATH**/ ?>