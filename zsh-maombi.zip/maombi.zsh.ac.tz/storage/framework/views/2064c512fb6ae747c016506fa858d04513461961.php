<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage User Accounts</h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add user')): ?>
        <div class="float-end">
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary btn-sm">Add user</a>
        </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col">
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Created at</th>
                    <th>Updated at</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->type); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td><?php echo e($user->updated_at); ?></td>
                        <td class="text-nowrap">
                            <div class="btn-group float-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view permission')): ?>
                                    <a href="<?php echo e(route('show.permission', $user)); ?>" class="btn btn-info btn-sm">
                                        <i class="fa fa-lock"></i> Permissions
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                                    <a href="<?php echo e(route('user.reset.password', $user)); ?>" class="btn btn-secondary btn-sm" onclick="return confirm('Are you sure ! \nDo you want to reset Password ?')">Reset Password</a>
                                    <a href="<?php echo e(route('user.edit', $user)); ?>" class="btn btn-success btn-sm">Edit</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                    <a href="<?php echo e(route('user.delete', $user)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ! \nDo you want to delete ?')">Remove</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/users/index.blade.php ENDPATH**/ ?>