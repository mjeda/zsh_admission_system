<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Intake</h1>
    </div>
    <!-- Form --->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['add intake', 'edit intake'])): ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-title">
                <h5 class="text-muted font-weight-bold"><?php if($intake->exists): ?> Edit <?php else: ?> Add <?php endif; ?> Intake</h5>
            </div>
            <div class="row">
                <div class="col">
                    <form action="<?php if($intake->exists): ?> <?php echo e(route('intake.update', $intake)); ?> <?php else: ?> <?php echo e(route('intake.store')); ?> <?php endif; ?>" method="POST" class="pb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12 col-md-3 pt-3 pr-3 pl-3">
                                <label for="title" class="form-label">Intake</label>
                                <select class="form-select  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="title">
                                    <?php if($intake->title == 'March'): ?>
                                        <option value="March">March</option>
                                        <option value="September">September</option>
                                    <?php else: ?>
                                        <option value="September">September</option>
                                        <option value="March">March</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="round" class="form-label">Round</label>
                                <input type="number" value="<?php echo e($intake->round); ?>" min="1" max="5" class="form-control  <?php $__errorArgs = ['round'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="round" id="round">
                                <?php $__errorArgs = ["round"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="year">Year</label>
                                <input type="text" value="<?php echo e($intake->year); ?>" min="4" max="4" class="form-control  <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="year" id="year" placeholder="Year">
                                <?php $__errorArgs = ["year"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="type">Type</label>
                                <select class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type">
                                    <option value="<?php echo e($intake->type ?? ""); ?>"><?php echo e($intake->type ?? "--- Select type ---"); ?></option>
                                    <?php if($intake->exists): ?>
                                        <?php if($intake->type == "Diploma"): ?>
                                            <option value="VTA/VETA">VTA/VETA</option>
                                        <?php else: ?>
                                            <option value="Diploma">Diploma</option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="Diploma">Diploma</option>
                                        <option value="VTA/VETA">VTA/VETA</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ["type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-3 pt-3 pr-3 pl-3">
                                <label for="expire_date" class="form-label">End date</label>
                                <input type="date" value="<?php echo e($intake->expire_date); ?>" min="<?php echo e(date('Y-m-d')); ?>" class="form-control  <?php $__errorArgs = ['expire_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="expire_date" id="expire_date">
                                <?php $__errorArgs = ["expire_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 pt-3 pr-3">
                                <div class="btn-group float-right">
                                    <button type="submit" class="btn <?php if($intake->exists): ?> btn-success <?php else: ?> btn-primary <?php endif; ?>" >
                                        <?php if($intake->exists): ?> Edit <?php else: ?> Add <?php endif; ?> intake
                                    </button>
                                    <?php if($intake->exists): ?>
                                        <a href="<?php echo e(route("intake.index")); ?>" class="btn btn-light">Cancel</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- List --->
    <div class="row">
        <div class="col">
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th >Name</th>
                    <th class="text-center">Round</th>
                    <th>Year</th>
                    <th>Closed_date</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Created_at</th>
                    <th>Updated_at</th>
                    <th width="200"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td class="text-center"><?php echo e($item->round); ?></td>
                        <td><?php echo e($item->year); ?></td>
                        <td><?php echo e($item->expire_date); ?></td>
                        <td><?php echo e($item->type); ?></td>
                        <td>
                            <?php if($item->status == "Open"): ?>
                                <strong class="text-info ">Open</strong>
                            <?php else: ?>
                                <strong class="text-danger ">Close</strong>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(date_format($item->created_at, 'd-m-y')); ?></td>
                        <td><?php echo e(date_format($item->updated_at, "d-m-y")); ?></td>
                        <td>
                            <div class="btn-group float-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('change intake status')): ?>
                                    <a href="<?php echo e(route('intake.status', $item)); ?>" class="btn <?php echo e(($item->status == "Open") ? "btn-danger" : "btn-info"); ?>  btn-sm"
                                       onclick="return confirm('Are you sure! \nDo you want to <?php echo e(($item->status == "Open") ? "Close" : "Open"); ?> ?')">
                                        <?php echo e(($item->status == "Open") ? "Close" : "Open"); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit intake')): ?>
                                <a href="<?php echo e(route('intake.index', $item)); ?>" class="btn btn-success btn-sm">Edit</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete intake')): ?>
                                <a href="<?php echo e(route('intake.delete', $item)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ! \nDo you want to delete ?')">Remove</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($intakes->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/intakes/index.blade.php ENDPATH**/ ?>