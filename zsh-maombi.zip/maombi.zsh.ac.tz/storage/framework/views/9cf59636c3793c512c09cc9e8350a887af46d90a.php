<?php $__env->startSection('content'); ?>
    <div class="card shadow-sm mb-4">
        
        <?php if($active_intake): ?>
            <div class="card-body">
                <h4 class="mb-4">📄 My applications</h4>
                <h5 class="fw-bold">
                    Application for <?php echo e($currentApplication?->intake?->title); ?> Intake: Round <?php echo e($currentApplication?->intake?->round); ?>

                </h5>

                <?php if($currentApplication): ?>
                    <?php if($currentApplication->status === 'SELECTED'): ?>
                        <p class="text-success mb-1">
                            🎉 Congratulations! You have been SELECTED for the following course:
                        </p>
                        <p class="fw-bold text-capitalize mb-0">
                            <?php echo e($currentApplication->selection->course->name); ?>

                        </p>

                        <div class="alert alert-info">
                            <?php if($currentApplication->registrationControlNumber): ?>
                                📝 Tafadhali fanya malipo ya usaili kwa kutumia namba ya udhibiti (Control Number)
                                ** <strong><?php echo e($currentApplication->registrationControlNumber->control_number); ?></strong> **
                                <br><br>
                                Malipo yanaweza kufanyika kwa njia zifuatazo:<br>
                                1. Kupitia benki ya PBZ moja kwa moja au wakala wake.<br>
                                2. Kwa simu, kutumia njia ya Lipa kwa Mix By Yas (ikiwa inapatikana).
                                <br><br>
                                🕒 Mwisho wa kufanya malipo: <strong><?php echo e($currentApplication->registrationControlNumber->expire_date->format('d M Y')); ?></strong>
                            <?php else: ?>
                                Tafadhali subiri namba ya udhibiti (Control Number) kwa ajili ya kufanya malipo ya usaili.
                            <?php endif; ?>
                        </div>

                    <?php else: ?>
                        <p class="text-primary mb-1">✅ You have already submitted your application.</p>
                        <p class="mb-0"><strong>Status:</strong> <?php echo e($currentApplication->status); ?></p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-muted">You have not completed an application for this intake.</p>
                    <a href="<?php echo e(route('portal-admission')); ?>" class="btn btn-primary mt-2">
                        ➕ New Application
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if($previousApplications): ?>
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="fw-bold">📌 Previous Application</h5>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Intake</th>
                                <th>Step</th>
                                <th>Created Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $previousApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $previousApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($previousApplication->intake?->title ?? '-'); ?> - Round <?php echo e($previousApplication->intake?->round ?? '-'); ?></td>
                                    <td>
                                        <?php if($previousApplication->step == 4 && $previousApplication->status != 'CREATED'): ?>
                                            4 - finished
                                        <?php elseif($previousApplication->step == 4 && $previousApplication->status == 'CREATED'): ?>
                                            4 - Not Completed
                                        <?php else: ?>
                                            Step - <?php echo e($previousApplication->step); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($previousApplication->created_at->format('d F, Y')); ?></td>
                                    <td class="fw-bold <?php echo e($previousApplication->status === 'SELECTED' ? 'text-success' : 'text-info'); ?>">
                                        <?php echo e($previousApplication->status); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/portal/application.blade.php ENDPATH**/ ?>