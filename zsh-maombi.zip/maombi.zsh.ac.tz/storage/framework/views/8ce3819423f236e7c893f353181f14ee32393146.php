<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h1 class="h3 mb-3">Permission For <strong><?php echo e($user->name); ?></strong></h1>
        </div>
        <div class="col">
            <a href="<?php echo e(route('user.index')); ?>"  class="btn btn-sm btn-primary float-end">
                <span class="fa fa-step-backward me-2"></span> User list
            </a>
        </div>
    </div>

    <div class="card card-body border-0 shadow table-wrapper table-responsive">
        <form action="<?php echo e(route("store.permission", $user)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="accordion" id="accordionExample">
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card my-2 border-0">
                        <div class="border border-light-primary" id="heading<?php echo e($loop->index); ?>" style="background: #3c4b64">
                            <h4 class="m-2 text-white-50 text-capitalize">
                                <i class="fa fa-arrow-alt-circle-down"></i> <?php echo e($group->group); ?>

                            </h4>
                        </div>
                        <div class="row">
                            <div class="card-body row">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if( $group->group == $permission->group): ?>
                                        <div class="col-12 col-sm-6 col-md-3 col-lg-3 py-0 ml-3 d-block">
                                            <input type="checkbox"
                                                   <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($userPermission->name == $permission->name): ?>
                                                   checked
                                                   <?php endif; ?>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   id="<?php echo e($permission->id); ?>"
                                                   value="<?php echo e($permission->name); ?>" name="permissions[]">
                                            <label for="<?php echo e($permission->id); ?>"> <?php echo e(ucfirst($permission->name)); ?></label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row mt-3">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary pull-right">
                        <i class="fa fa-refresh"></i> Sync Permission
                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/users/permissions.blade.php ENDPATH**/ ?>