<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register-component')->html();
} elseif ($_instance->childHasBeenRendered('5HcSW7u')) {
    $componentId = $_instance->getRenderedChildComponentId('5HcSW7u');
    $componentTag = $_instance->getRenderedChildComponentTagName('5HcSW7u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5HcSW7u');
} else {
    $response = \Livewire\Livewire::mount('register-component');
    $html = $response->html();
    $_instance->logRenderedChild('5HcSW7u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/auth/register.blade.php ENDPATH**/ ?>