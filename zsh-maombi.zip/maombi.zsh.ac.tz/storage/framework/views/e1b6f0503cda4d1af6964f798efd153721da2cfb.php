<?php $__env->startSection('content'); ?>
    <div class="float-right mt-2">
        <a href="<?php echo e(route('admission.reset.password', $admission->user->id)); ?>" class="btn btn-primary" onclick="return confirm('Do you want to reset password?')">
            Reset password
        </a>
        <button type="button" class="btn btn-success text-black" data-bs-toggle="modal" data-bs-target="#updateModal">
            Update info ...
        </button>
        <a href="#" class="btn btn-secondary" onclick="PrintElem('#printer')"><i class="fa fa-print"></i> Print</a>
    </div>
    <div id="printer">
        <div
            class="align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h2 class="h4">Application of
                <i class="font-weight-bold"><?php echo e($admission->first_name ." ". $admission->middle_name ." ". $admission->last_name); ?></i>
            </h2>
            <h3> <?php echo e($admission->index_number); ?> (<?php echo e($admission->intake->title .' '. $admission->intake->year); ?> Intake)</h3>
        </div>
        <!-- Personal info --->
        <fieldset>
            <legend class="text-info">Personal Information</legend>
            <div class="table-responsive">
                <table class="table table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th>School name</th>
                        <th>Index Number</th>
                        <th>Gender</th>
                        <th>DOB</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Region</th>
                        <th>District</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo e($admission->school_name); ?></td>
                        <td><?php echo e($admission->index_number); ?></td>
                        <td><?php echo e($admission->gender); ?></td>
                        <td><?php echo e($admission->dob); ?></td>
                        <td><?php echo e($admission->email); ?></td>
                        <td><?php echo e($admission->phone); ?></td>
                        <td><?php echo e($admission->address); ?></td>
                        <td><?php echo e($admission->region); ?></td>
                        <td><?php echo e($admission->district); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </fieldset>
        <!-- Next of kin info --->
        <fieldset>
            <legend class="text-info">Next of kin Information</legend>
            <div class="table-responsive">
                <table class="table table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th>Full name</th>
                        <th>Relation</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>District</th>
                        <th>Region</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($admission->next_of_kin_phone != null): ?>
                        <tr>
                            <td><?php echo e($admission->next_of_kin_name); ?></td>
                            <td><?php echo e($admission->next_of_kin_relation); ?></td>
                            <td><?php echo e($admission->next_of_kin_phone); ?></td>
                            <td><?php echo e($admission->next_of_kin_email); ?></td>
                            <td><?php echo e($admission->next_of_kin_address); ?></td>
                            <td><?php echo e($admission->next_of_kin_district); ?></td>
                            <td><?php echo e($admission->next_of_kin_region); ?></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger">
                                Information of next of kin not filled
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </fieldset>
        <!-- Payment info --->
        <fieldset>
            <legend class="text-info">Payment Information</legend>
            <div class="table-responsive">
                <table class="table  table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th>Control number</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($admission->controlNumber != null): ?>
                        <?php if($admission->controlNumber->payment != null): ?>
                            <tr>
                                <td><?php echo e($admission->controlNumber->control_number); ?></td>
                                <td><?php echo e($admission->controlNumber->payment->amount); ?></td>
                                <td><?php echo e($admission->controlNumber->payment->payment_method); ?></td>
                                <td><?php echo e($admission->controlNumber->payment->payment_date); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center text-danger">
                                    The control number <b><?php echo e($admission->controlNumber->control_number); ?></b> not paid
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger">
                                Control number not generated because admission not completed
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </fieldset>
        <!-- Selected Course info --->
        <fieldset>
            <legend class="text-info">Course Selected</legend>
            <div class="table-responsive">
                <table class="table  table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th>Course code</th>
                        <th>Course name</th>
                        <th>Priority</th>
                        <th>Selected at</th>
                        <th class="hide">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $admission->selectedCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($selected->course != null): ?>
                                <tr>
                                    <td><?php echo e($selected->course->tag); ?></td>
                                    <td><?php echo e($selected->course->name); ?></td>
                                    <td><?php echo e($selected->priority); ?></td>
                                    <td><?php echo e($selected->created_at); ?></td>
                                    <td class="hide">
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#changeModal" data-id="<?php echo e($selected->id); ?>">
                                            Change
                                        </button>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center text-danger">
                                        Not selected any course
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center text-danger">
                                    <?php if($admission->controlNumber != null): ?>
                                        <?php if($admission->controlNumber->payment != null): ?>
                                        <a href="<?php echo e(route('admission.update', $admission->id)); ?>" class="btn btn-warning">Reload Results</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </fieldset>

        <!-- Result info --->
        <fieldset>
            <legend class="text-info">Results</legend>
            <?php $__empty_1 = true; $__currentLoopData = $admission->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <p>Index Number: <?php echo e(json_decode($result->result_payload)->particulars->index_number); ?></p>
                <div class="table-responsive">
                    <table class="table  table-striped border-left border-right border-bottom">
                        <thead>
                        <tr>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th>Grade</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_2 = true; $__currentLoopData = json_decode($result->result_payload)->subjects ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <tr>
                                <td><?php echo e($payload->subject_code); ?></td>
                                <td><?php echo e($payload->subject_name); ?></td>
                                <td><?php echo e($payload->grade); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </fieldset>
    </div>
    <!-- Change Course Modal -->
    <div class="modal fade" id="changeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Course</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="changeCourseForm">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="course">Select Course</label>
                            <select id="course" name="course" class="form-control">
                                <option value="">--Select--</option>
                                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($course->id); ?>"> <?php echo e($course->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Update Information Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Student Information</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('admission.update.info', $admission->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" value="<?php echo e($admission->email); ?>" class="form-control" name="email" id="email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone number</label>
                            <input type="text" value="<?php echo e($admission->phone); ?>" id="phone_number" name="phone" class="form-control">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        let changeCourseBtns = document.querySelectorAll(".btn[data-bs-target='#changeModal']");

        changeCourseBtns.forEach(function (btn) {
            btn.addEventListener("click", function () {
                let courseId = this.getAttribute("data-id");
                let form = document.getElementById("changeCourseForm");
                
                // Update the form action correctly
                form.action = "<?php echo e(url('admission')); ?>/change/" + courseId ;
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/admissions/show.blade.php ENDPATH**/ ?>