<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Control Number List</h1>
    </div>
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route('control-numbers')); ?>" class="form-inline mb-3">
                <input type="search" placeholder="Search by Control Number.." name="keyword" class="form-control">
                <input type="submit" value="Search" class="btn btn-primary ml-2">
            </form>
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th>Applicant & Admission</th>
                    <th>Control number</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Created at</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pay control number', 'extend time'])): ?>
                    <th>Action</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $control_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td> <?php echo e($item->admission?->full_name); ?>-
                            <a href="#"><?php echo e($item->admission?->index_number); ?></a>
                        </td>
                        <td><?php echo e($item->control_number); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pay control number', 'extend time'])): ?>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pay control number')): ?>
                                <?php if($item->status != 'PAID'): ?>
                                <a href="<?php echo e(route('cash.payment', ['control_number' => $item->control_number, 'isCash'=>true])); ?>" class="btn btn-primary btn-sm" onclick="return confirm('Are You Sure?')">Mark as Paid</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('extend time')): ?>
                                <?php if($item->status == 'CREATED'): ?>
                                <a href="<?php echo e(route('control-number.extend-time', $item->id)); ?>" class="btn btn-warning btn-sm" onclick="return confirm('Are You Sure! Do you want to Extend time ?')">Extend time</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($control_numbers->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/control-numbers/index.blade.php ENDPATH**/ ?>