<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Course Criteria</h1>
    </div>
    <!-- Form --->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['add criteria', 'edit criteria'])): ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-title">
                <h5 class="text-muted font-weight-bold"><?php if($course_criteria->exists): ?> Edit <?php else: ?> Add <?php endif; ?> Criteria</h5>
            </div>
            <div class="row">
                <div class="col">
                    <form action="<?php if($course_criteria->exists): ?> <?php echo e(route('criteria.update', $course_criteria)); ?> <?php else: ?> <?php echo e(route('criteria.store', $course)); ?> <?php endif; ?>" method="POST" class="pb-3">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12 col-md-4 pt-3 pr-3 pl-3">
                                <label for="title">Subject Name</label>
                                <input type="text" value="<?php echo e($course_criteria->title); ?>" class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" id="title" placeholder="eg. KISWAHILI">
                                <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="value">Minimum Grade</label>
                                <input type="text" value="<?php echo e($course_criteria->value); ?>" class="form-control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="value" id="value" placeholder="eg. D">
                                <?php $__errorArgs = ["value"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-2 pt-3 pr-3 pl-3">
                                <label for="value">Filter</label>
                                <select  class="form-control <?php $__errorArgs = ['filter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="filter" id="filter">
                                    <option value="">-- Select Filter --</option>
                                    <option value="Include" <?php echo e($course_criteria->filter == 'Include' ? 'selected' : ''); ?>>Include</option>
                                    <option value="Exclude" <?php echo e($course_criteria->filter == 'Exclude' ? 'selected' : ''); ?>>Exclude</option>
                                    <option value="Advantage" <?php echo e($course_criteria->filter == 'Advantage' ? 'selected' : ''); ?>>Advantage</option>
                                    <option value="Alternative" <?php echo e($course_criteria->filter == 'Alternative' ? 'selected' : ''); ?>>Alternative</option>
                                </select>
                                <?php $__errorArgs = ["filter"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-4 pt-3 pr-3 pl-3" id="alt-for-section" style="<?php echo e($course_criteria->filter == 'Alternative' ? '' : 'display: none;'); ?>">
                                <label for="alternative_for">Alternative For (Subject to be compensated)</label>
                                <input type="text" value="<?php echo e($course_criteria->alternative_for); ?>" class="form-control <?php $__errorArgs = ['alternative_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alternative_for" id="alternative_for" placeholder="eg. PHYSICS">
                                <?php $__errorArgs = ["alternative_for"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row  pt-3 pr-4">
                            <div class="col">
                                <div class="btn-group">
                                    <button type="submit" class="btn btn-sm <?php if($course_criteria->exists): ?> btn-success <?php else: ?> btn-primary <?php endif; ?>" >
                                        <?php if($course_criteria->exists): ?> Edit <?php else: ?> Add <?php endif; ?> criteria
                                    </button>
                                    <?php if($course_criteria->exists): ?>
                                        <a href="<?php echo e(route("criteria.index", $course)); ?>" class="btn btn-light btn-sm">Cancel</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- List --->
    <div class="row">
        <div class="col">
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th width="35px" class="border-right">SN</th>
                    <th width="450">Subject Name</th>
                    <th>Minimum Grade</th>
                    <th>Filter</th>
                    <th>Created at</th>
                    <th>Updated at</th>
                    <th width="200"></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->value); ?></td>
                        <td><?php echo e($item->filter); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($item->updated_at); ?></td>
                        <td>
                            <div class="btn-group float-right">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit criteria')): ?>
                                <a href="<?php echo e(route('criteria.index', [$course, $item])); ?>" class="btn btn-success btn-sm">Edit</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete criteria')): ?>
                                <a href="<?php echo e(route('criteria.delete', $item)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure ! \nDo you want to delete ?')">Remove</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No content in this table
                    </td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($criteria->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const filterSelect = document.getElementById('filter');
            const altSection = document.getElementById('alt-for-section');

            function toggleAltSection() {
                if (filterSelect.value === 'Alternative') {
                    altSection.style.display = '';
                } else {
                    altSection.style.display = 'none';
                }
            }

            filterSelect.addEventListener('change', toggleAltSection);
            toggleAltSection(); // initial call
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/criteria/index.blade.php ENDPATH**/ ?>