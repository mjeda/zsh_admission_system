<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Admission of
            <i class="font-weight-bold"><?php echo e($admission->first_name ." ". $admission->middle_name ." ". $admission->last_name); ?> - <?php echo e($admission->index_number); ?></i>
        </h1>
    </div>
    <!-- Personal info --->
    <fieldset>
        <legend style="color: #e3b04b">Personal Information</legend>
        <div class="table-responsive">
            <table class="table table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th>School name</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Region</th>
                    <th>District</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($admission->school_name); ?></td>
                    <td><?php echo e($admission->gender); ?></td>
                    <td><?php echo e($admission->dob); ?></td>
                    <td><?php echo e($admission->email); ?></td>
                    <td><?php echo e($admission->phone); ?></td>
                    <td><?php echo e($admission->address); ?></td>
                    <td><?php echo e($admission->region); ?></td>
                    <td><?php echo e($admission->district); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </fieldset>
    <!-- Next of kin info --->
    <fieldset>
        <legend style="color: #e3b04b">Next of kin Information</legend>
        <div class="table-responsive">
            <table class="table table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th>Full name</th>
                    <th>Relation</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>District</th>
                    <th>Region</th>
                </tr>
                </thead>
                <tbody>
                <?php if($admission->next_of_kin_phone != null): ?>
                <tr>
                    <td><?php echo e($admission->next_of_kin_name); ?></td>
                    <td><?php echo e($admission->next_of_kin_relation); ?></td>
                    <td><?php echo e($admission->next_of_kin_phone); ?></td>
                    <td><?php echo e($admission->next_of_kin_email); ?></td>
                    <td><?php echo e($admission->next_of_kin_address); ?></td>
                    <td><?php echo e($admission->next_of_kin_district); ?></td>
                    <td><?php echo e($admission->next_of_kin_region); ?></td>
                </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center text-danger">
                            Information of next of kin not filled
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </fieldset>
    <!-- Payment info --->
    <fieldset>
        <legend style="color: #e3b04b">Payment Information</legend>
        <div class="table-responsive">
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th>Control Number</th>
                    <th>Receipt</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Date</th>
                </tr>
                </thead>
                <tbody>
                <?php if($admission->controlNumber != null): ?>
                    <?php if($admission->controlNumber->payment != null): ?>
                        <tr>
                            <td><?php echo e($admission->controlNumber->control_number); ?></td>
                            <td><?php echo e($admission->controlNumber->payment->receipt); ?></td>
                            <td><?php echo e($admission->controlNumber->payment->amount); ?></td>
                            <td><?php echo e($admission->controlNumber->payment->payment_method); ?></td>
                            <td><?php echo e($admission->controlNumber->payment->payment_date); ?></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger">
                                The control number <b><?php echo e($admission->controlNumber->control_number); ?></b> not paid
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center text-danger">
                            Control number not generated because admission not completed
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </fieldset>
    <!-- Selected Course info --->
    <fieldset>
        <legend style="color: #e3b04b">Course Selected</legend>
        <div class="table-responsive">
            <table class="table  table-striped border-left border-right border-bottom">
                <thead>
                <tr>
                    <th>Priority</th>
                    <th>Course name</th>
                    <th>Selected at</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $admission->selectedCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($selected->course != null): ?>
                        <tr>
                            <td><?php echo e($selected->priority); ?></td>
                            <td><?php echo e($selected->course->name); ?></td>
                            <td><?php echo e($selected->created_at); ?></td>
                        </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center text-danger">
                                    Not selected any course
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-danger">
                                Not selected any course
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </fieldset>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/portal/application-detail.blade.php ENDPATH**/ ?>