<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Applications by Course Report</h1>
    </div>
    <div class="row">
        <div class="col">
            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('report.admission_by_course')); ?>" class="form-inline mb-3">
                        <div class="form-group">
                            <label class="mr-1">Intake:</label>
                            <select name="intake" class="form-control">
                                <option value="">--- Select ---</option>
                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(request('intake') == $item->id ? 'selected' : ''); ?>>
                                        <?php echo e($item->type .' - '. $item->title .' round '. $item->round .', '. $item->year); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group ml-2">
                            <label class="mr-1">Course:</label>
                            <select name="course" class="form-control width-auto">
                                <option value="">--- Select ---</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(request('course') == $item->id ? 'selected' : ''); ?>>
                                        <?php echo e($item->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group ml-2">
                            <label class="mr-1">Status:</label>
                            <select name="status" class="form-control">
                                <option value="">--- Select ---</option>
                                <option value="CREATED" <?php echo e(request('status') == 'CREATED' ? 'selected' : ''); ?>>Incomplete</option>
                                <option value="SUBMITTED" <?php echo e(request('status') == 'SUBMITTED' ? 'selected' : ''); ?>>Completed</option>
                            </select>
                        </div>

                        <div class="btn-group">
                            <input type="submit" value="Filter" class="btn btn-primary ml-2 pull">
                            <a href="<?php echo e(route('report.admission')); ?>" class="btn btn-light">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('download admission report')): ?>
                <div class="col-md-1">
                    <button type="button" class="btn btn-secondary float-right" id="print_btn">
                        Print
                    </button>
                </div>
                <?php endif; ?>
            </div>

            <div class="table-responsive" id="div_to_print">
                <?php echo $notify; ?>

                <table class="table table-striped border-left border-right border-bottom">
                    <thead>
                    <tr>
                        <th width="35px" class="border-right">SN</th>
                        <th>Full name</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <th>Index Number</th>
                        <th>School Name</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td width="35px" class="border-right"><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->first_name ." ". $item->middle_name ." ". $item->last_name); ?></td>
                            <td><?php echo e($item->gender); ?></td>
                            <td><?php echo e($item->phone); ?></td>
                            <td><?php echo e($item->index_number); ?></td>
                            <td><?php echo e($item->school_name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center">
                                No content in this table
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('printThis/jquery.printThis.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(e) {
            $('button#print_btn').on('click', function(e)  {
                $('#div_to_print').printThis({
                    styles: ["<?php echo e(asset("css/bootstrap.css")); ?>"]
                    // exclude: ['.do_not_print', '.print_exclude' ]
                    // also accept array input: exclude: [<array>]
                    // you can specify id, class or even html element tag
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zsh-maombi/htdocs/maombi.zsh.ac.tz/resources/views/reports/admissions_by_courses.blade.php ENDPATH**/ ?>