<?php return array (
  'admission.form' => 'App\\Http\\Livewire\\Admission\\Form',
  'register-component' => 'App\\Http\\Livewire\\RegisterComponent',
  'sms-component' => 'App\\Http\\Livewire\\SmsComponent',
  'veta.form-component' => 'App\\Http\\Livewire\\Veta\\FormComponent',
  'veta.register-component' => 'App\\Http\\Livewire\\Veta\\RegisterComponent',
  'veta._-register-component' => 'App\\Http\\Livewire\\Veta\\_RegisterComponent',
);